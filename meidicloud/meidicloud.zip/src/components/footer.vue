<template>
	<div class="footer">
		<p>京ICP备：08024564 ©medi-cloud.cn ALL Rights Reserved 北京美迪云医疗科技有限公司 版权所有</p>
	</div>
</template>

<script>
</script>

<style>
	.footer{		
	    width: 100%;
	    min-width: 1200px;
	    height: 140px;
	    color: #fff;
	    line-height: 40px;
	    z-index: 999;
	    text-align: center;	  	    
	   padding-top: 100px;
	   box-sizing: border-box;
	   background: white;
	    
	}
	.footer p{
		margin: 0;
		width: 100%;
		height: 40px;
		display: block;
		background: #212121;
	    font-size: 15px;
	}
	
</style>