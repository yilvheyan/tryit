<template>
	<div class="indexbox">
		<oheader></oheader>joinmdc
		<obanner class='indexbanner' :msgbanner='indexone'></obanner>
		<obannerz class='indexbannerzcss' :msgbannerz='joinmdcbannerzone'></obannerz>
		<obannerz class='indexbannerzcssone' :msgbannerz='joinmdcbannerztwo'></obannerz>
		<div class="joinmdclist">
			<div class="joinmdclistbox">
				<div class="joinmdclistone one">
					<div class="joinmdcmengban">
						<div class="joinmdconetitle">与优秀的人同行 你将遇见最好的自己</div>
						<div class="joinmdconelist">
							<div class="joinmdcspan">耗材销售</div>
							<div class="joinmdcspan">市场专员</div>
							<div class="joinmdcspan">文案编辑</div>
							<div class="joinmdcspan">云销售</div>
							<div class="joinmdcspan">医疗机械售后工程师</div>
						</div>
					</div>
					
				</div>
				<div class="joinmdclistone two">
				
				</div>
			</div>
			
			
			
		</div>
		<obannerz class='indexbannerzcssone' :msgbannerz='joinmdcbannerzthree'></obannerz>
		<ocirculate class='indocirculatecss' :msgcirculate='indexcirculatetwo'></ocirculate>
		<ocirculate class='indocirculatecssthree' :msgcirculate='indexcirculatethree'></ocirculate>
		<ofooter></ofooter>
	</div>
</template>

<script>
	
	import oheader from '../components/header'
	import obanner from '../components/banner'
	import obannerz from '../components/bannerz'
	import ocirculate from '../components/circulate'
	import ofooter from '../components/footer'
	export default{
		data(){
			return{
				indexone:3,
				joinmdcbannerzone:[3,0],
				joinmdcbannerztwo:[3,1],
				joinmdcbannerzthree:[3,2],
				indexcirculatetwo:[1,'oneyetwo','mengban'],
				indexcirculatethree:[2,'oneyethree','mengban']
				
			}
		},
		components:{
			oheader,
			obanner,
			obannerz,
			ocirculate,
			ofooter
		}
	}
</script>

<style>
	.indexbox{
		
		position: relative;
	}
	.indexbanner{
		width: 100%;
	    min-width: 1200px;
	    position: fixed;
	    left: 0;
	    top: 0;
	    right: 0;
	    height: 650px;
	    z-index: -1;
	}
	.indexbannerzcss{
		width: 100%;
	    min-width: 1200px;
	    height: 650px;
	    color: white;
	}
	.indexbannerzcssone{
		width: 100%;
	    min-width: 1200px;
	    height: 300px;
	    color: black;
	    background: white;
	    
	    z-index: 10;
	}
	.indocirculatecss{
		width: 100%;
		background: white;
		z-index: 10;
	}
	.indocirculatecssthree{
		width: 100%;
		background: white;
		z-index: 10;
		padding-top: 100px;
		box-sizing: border-box;
	}
	.joinmdclist{
		width: 100%;
		height: 352px;
		background: white;
		z-index: 10;
	}
	.joinmdclistbox{
		width: 80%;
		min-width: 1200px;
		margin: 0 auto;
		display: flex;
	}
	.joinmdclistone{
		flex: 1;
		width: 47%;
		height: 352px;
		margin-right: 4.5%;
		
		color: white;
		text-align: center;
		position: relative;
	}
	.one{
		background: url(../../static/zw.jpg);
		background-size: 100%;
	}
	.two{
		background: url(../../static/xw.jpg);
		background-size: 100%;
	}
	.joinmdconetitle{
		width: 100%;
		font-size: 21px;
		height: 30px;
		line-height: 30px;
	}
	.joinmdcmengban{
		width: 100%;
		height: 100%;
		background: rgba(24, 24, 24, .4);
		position: absolute;
		padding-top: 100px;
		box-sizing: border-box;
		top: 0;
		left: 0;
	}
	.joinmdconelist{
		margin-top: 50px;
		width: 80%;
		margin: 0 auto;
	}
	.joinmdcspan{
		float: left;
		font-size: 15px;
		padding: 10px 20px;
		border: 2px solid white;
		margin-top: 30px;
		margin-right: 30px;
	}
</style>