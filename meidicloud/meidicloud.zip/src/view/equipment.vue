<template>
	<div class="indexbox">
		<oheader></oheader>
		<obanner class='indexbanner' :msgbanner='introduceone'></obanner>
		<obannerz class='indexbannerzcss' :msgbannerz='equipmentbannerone'></obannerz>
		<div class="main">
			<div class="maintitle">
				<span class="shapone">设备租赁</span>
				<span class="shaptwo">010-5954-8080 or 400-900-1660</span>
			</div>
			<div class="mainxinxi">
				<p class="mainp">我们的优势</p>
				<p class="mainp">为您提供设备整体解决方案，通过医疗设备云共享的方式，极大降低医院的设备使用成本</p>
				<p class="mainpone"> 降低了医院设备使用成本；</p>
				<p class="mainpone"> 提升了医院设备更新速度；</p>
				<p class="mainpone"> 节约了医院设备维护成本；</p>
				<p class="mainp">在医院对医疗设备形成需求时，通过自行购买往往需要动用大量的资金，单纯依靠国家财政拨款和医院自筹，无法满足医院发展的要求.即便资金到位，
					也要从市场需求的实际情况出发，综合考虑以下问题</p>
				<p class="mainpone">医院使用这些器械的频率？</p>
				<p class="mainpone"> 是否因为闲置造成资源的浪费？；</p>
				<p class="mainpone"> 能否在合适的投资期收回成本？</p>
				<p class="mainpone"> 何时为医院实现盈利？；</p>
				<p class="mainpone"> 是否有充足的设备更新维护预算？</p>
				<p class="mainp">这些悬而未决的问题，都是院方设备购买的风险，都有可能成为制约医疗机构引进先进医疗设备、
					提升医疗机构医疗服务水平的瓶颈</p>
				<p class="mainp">通过引入美迪云的设备整体解决方案，这些后顾之忧都不复存在。 美迪云能使得医院用更低的成本，在更低的风险下，
					提前受益与一线城市医疗机构同等级别的世界领先的设备。</p>
				<p class="mainp">美迪云为各家医院所提供的方案，是由我们美迪云的专业顾问团队，通过实地走访，了解院方运营的实际情况、
					设备需求的情况后，以大数据的客户需求分析为支撑，为医院提供满足市场需求的整体设备解决方案。通过云共享来实现设备的随用随取，
					必将成为获取产业用品性价比最高的方式。必然也会成为医疗机构解决设备更新过慢行之有效的方式</p>
				<p class="mainp">公司地址：北京市昌平区回龙观西大街龙冠商务中心银座525室</p>
				<div style="margin-top: 70px;">
					<img src="../../static/csy.png" />
				</div>
			</div>
		</div>
		<ofooter></ofooter>
	</div>
</template>

<script>
	
	import oheader from '../components/header'
	import obanner from '../components/banner'
	import obannerz from '../components/bannerz'
	import ofooter from '../components/footer'
	export default{
		data(){
			return{
				introduceone:1,
				equipmentbannerone:[2,0]
			}
		},
		components:{
			oheader,
			obanner,
			obannerz,
			ofooter
		}
	}
</script>

<style>
	.indexbox{
		
		position: relative;
	}
	.indexbanner{
		width: 100%;
	    min-width: 1200px;
	    position: fixed;
	    left: 0;
	    top: 0;
	    right: 0;
	    height: 650px;
	    z-index: -1;
	}	
	.indexbannerzcss{
		width: 100%;
	    min-width: 1200px;
	    height: 650px;
	    color: white;
	}
	.main{
		width: 100%;
		background: white;
		z-index: 10;
		padding-top: 90px;
		box-sizing: border-box;
	}
	.maintitle{
		width: 1200px;
		margin: 0 auto;
		border-bottom: 1px solid gainsboro;
		padding-left: 80px;
		box-sizing: border-box;
		height: 57px;
		text-align: left;
		font-size: 30px;
		line-height: 57px;
	}
	.mainxinxi{
		width: 1200px;
		margin: 0 auto;
		padding-left: 80px;
		box-sizing: border-box;
	}
	.mainp{
		text-align: left;
		font-size: 20px;
		margin-bottom: 0;
	}
	.mainpone{
		text-align: left;
		font-size: 15px;
		color: #ccc;
		margin-bottom: 0;
	}
	.shapone{
		font-size: 30px;
	}
	.shaptwo{
		margin-left: 30px;
		font-size: 20px;
	}
</style>