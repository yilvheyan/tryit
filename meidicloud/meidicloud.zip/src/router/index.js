import Vue from 'vue'
import Router from 'vue-router'
//import HelloWorld from '@/components/HelloWorld'
import index from '@/view/index'
import introduce from '@/view/introduce'
import equipment from '@/view/equipment'
import joinmdc from '@/view/joinmdc'




Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'index',
      component: index
    },
    {
      path: '/introduce',
      name: 'introduce',
      component: introduce
    },
    {
      path: '/index',
      name: 'index',
      component: index
    },
    {
      path: '/equipment',
      name: 'equipment',
      component: equipment
    },
    {
      path: '/joinmdc',
      name: 'joinmdc',
      component: joinmdc
    }
  ]
})
